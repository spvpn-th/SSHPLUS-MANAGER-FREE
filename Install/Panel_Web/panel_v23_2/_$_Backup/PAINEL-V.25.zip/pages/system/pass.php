<?php $pass = '1010';?>
